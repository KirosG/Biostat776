# dplyr demo

library(dplyr, warn.conflicts = FALSE)
library(readr)
specdata <- read_csv("SPEC_2014.csv.gz")
dim(specdata)

## select()

select(specdata, 1:4)
names(specdata)
select(specdata, Date.Local:Observation.Count)
select(specdata, -(Date.Local:Observation.Count) )
select(specdata, starts_with("State"))
select(specdata, ends_with("Name"))

## filter()

specdata.f <- filter(specdata, Parameter.Name == "Sulfate PM2.5 LC")
select(specdata.f, 1:3, Parameter.Name)

specdata.f <- filter(specdata, Parameter.Name == "Sulfate PM2.5 LC"
                     & State.Name == "Texas")
select(specdata.f, 1:3, Parameter.Name, State.Name)

specdata.f <- filter(specdata, Parameter.Name == "Sulfate PM2.5 LC"
                     | State.Name == "Texas")
select(specdata.f, 1:3, Parameter.Name, State.Name)

## arrange()

specdata.a <- arrange(specdata, Date.Local)
select(specdata.a, Date.Local, Parameter.Name, Sample.Value)
specdata.a <- arrange(specdata, Date.Local, Parameter.Name)
select(specdata.a, Date.Local, Parameter.Name, Sample.Value)

specdata.a <- arrange(specdata, desc(Date.Local), desc(Parameter.Name))
select(specdata.a, Date.Local, Parameter.Name, Sample.Value)

## rename()

select(specdata, 1:7)
specdata.n <- rename(specdata, lat = Latitude, lon = Longitude)
select(specdata.n, 1:7)

## mutate()

specdata.m <- mutate(specdata, 
                     city_state = paste(City.Name, State.Name, sep = ", "),
                     sample_mg = Sample.Value / 1000)
select(specdata.m, City.Name, State.Name, city_state, sample_mg)

## group_by()

specdata.r <- mutate(specdata, 
                     region = factor(Longitude > -100, 
                                     labels = c("west", "east")))
eastwest <- group_by(specdata.r, region)
summarize(eastwest, pollutant = mean(Sample.Value, na.rm = TRUE),
          obs  = mean(Observation.Count, na.rm = TRUE))

library(lubridate)
specdata <- mutate(specdata, month = month(Date.Local))
months <- group_by(specdata, month)
months <- filter(months, Parameter.Name == "Sulfate PM2.5 LC")
summarize(months, sulfate = mean(Sample.Value, na.rm = TRUE))

## %>% 

specdata %>%
        mutate(month = month(Date.Local)) %>%
        filter(Parameter.Name == "Sulfate PM2.5 LC") %>%
        group_by(month) %>%
        summarize(sulfate = mean(Sample.Value, na.rm = TRUE))

specdata %>%
        mutate(month = month(Date.Local),
               region = factor(Longitude > -100, 
                               labels = c("west", "east"))) %>%
        filter(Parameter.Name == "Sulfate PM2.5 LC") %>%
        group_by(month, region) %>%
        summarize(sulfate = mean(Sample.Value, na.rm = TRUE)) %>%
        arrange(region, month)
        


















