# ggplot2 demo

library(ggplot2)
library(tidyverse)

glimpse(mpg)

qplot(displ, hwy, data = mpg)
qplot(displ, hwy, data = mpg,
      color = drv)

qplot(displ, hwy, data = mpg,
      geom = c("smooth"))

qplot(hwy, data = mpg, fill = "red")

qplot(displ, hwy, data = mpg,
      facets = drv ~ .)

qplot(hwy, data = mpg, binwidth = 2,
      facets = drv ~ .)

library(readr)
eno <- read_csv("eno.csv")
env <- read_csv("environmental.csv")
skin <- read_csv("skin.csv")
maacs <- left_join(eno, env, by = "id") %>%
        left_join(skin, by = "id")
glimpse(maacs)

qplot(log(eno), data = maacs,
      fill = mopos)

qplot(log(eno), data = maacs,
      geom = "density", 
      color = mopos)

qplot(log(pm25), log(eno), 
      data = maacs,
      color = mopos)

qplot(log(pm25), log(eno),
      data = maacs,
      color = mopos,
      geom = c("point", "smooth"),
      method = "lm")

qplot(log(pm25), log(eno),
      data = maacs,
      geom = c("point", "smooth"),
      facets = . ~ mopos,
      method = "lm")











































