# Demo Part 2

library(tidyverse)

maacs <- read_csv("maacs_bmi.csv")
glimpse(maacs)

qplot(logpm25, NocturnalSympt, 
      data = maacs, 
      geom = c("point", "smooth"),
      facets = . ~ bmicat,
      method = "lm")

ggplot(maacs, aes(x = logpm25, 
                  y = NocturnalSympt)) +
        geom_point() +
        geom_smooth(method = "lm",
                    se = FALSE) +
        facet_grid(bmicat ~ .)

ggplot(maacs,
       aes(x = logpm25,
           y = NocturnalSympt)) + 
        geom_point(aes(color = bmicat),
                   size = 4, alpha = 1/4) + 
        labs(title = "MAACS Cohort") +
        labs(x = "Log PM[2.5]") + 
        labs(y = "Nocturnal Symptoms") + 
        geom_smooth(method = "lm",
                    color = "violet",
                    size = 4,
                    linetype = 3)
ggplot(maacs, 
       aes(logpm25, NocturnalSympt)) + 
        geom_point(aes(color = bmicat)) +
        theme_bw(base_family = "Avenir")
        



colors()













